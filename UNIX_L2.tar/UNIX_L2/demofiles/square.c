#include <stdio.h>
int main()
{  int x;   printf("Enter a number\n");  scanf("%d",&x);  
   printf ("The square of your number is %d\n",x*x);   }
